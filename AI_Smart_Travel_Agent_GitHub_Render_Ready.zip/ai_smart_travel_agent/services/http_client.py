import requests
from config import REQUEST_TIMEOUT, USER_AGENT
SESSION = requests.Session()
SESSION.headers.update({"User-Agent": USER_AGENT})
def get_json(url, params=None, timeout=None):
    response = SESSION.get(url, params=params, timeout=timeout or REQUEST_TIMEOUT)
    response.raise_for_status()
    return response.json()
