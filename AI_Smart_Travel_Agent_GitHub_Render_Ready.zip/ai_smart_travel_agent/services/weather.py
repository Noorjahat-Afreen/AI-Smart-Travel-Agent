from services.http_client import get_json
def get_weather_forecast(lat, lon, start_date=None, end_date=None):
    params = {"latitude": lat, "longitude": lon, "daily": "weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max", "timezone": "auto"}
    if start_date and end_date:
        params.update({"start_date": start_date, "end_date": end_date})
    else:
        params["forecast_days"] = 7
    data = get_json("https://api.open-meteo.com/v1/forecast", params)
    daily = data.get("daily", {})
    result = []
    for i, day in enumerate(daily.get("time", [])):
        result.append({"date": day, "max_c": daily.get("temperature_2m_max", [None])[i],
                       "min_c": daily.get("temperature_2m_min", [None])[i],
                       "rain_probability": daily.get("precipitation_probability_max", [None])[i],
                       "weather_code": daily.get("weather_code", [None])[i]})
    return result
