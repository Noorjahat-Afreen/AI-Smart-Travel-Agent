import tempfile
import os
from datetime import date, timedelta
import gradio as gr
from agents.specialized_agents import collect_destination_data
from agents.master_agent import generate_plan
from services.database import init_db, save_trip
from services.vision import analyze_image
init_db()
def build_trip(origin,destination,start_date,end_date,travellers,budget,travel_mode,trip_type,interests):
    if not destination or not destination.strip(): raise gr.Error("Enter a destination.")
    if not start_date or not end_date: raise gr.Error("Enter both dates in YYYY-MM-DD format.")
    if end_date < start_date: raise gr.Error("Return date must be on or after departure date.")
    if int(travellers)<1 or float(budget)<=0: raise gr.Error("Travellers and budget must be positive.")
    req={"origin":(origin or "").strip(),"destination":destination.strip(),"start_date":str(start_date),"end_date":str(end_date),
         "travellers":int(travellers),"budget":float(budget),"travel_mode":travel_mode,"trip_type":trip_type,"interests":interests or ""}
    try:
        bundle=collect_destination_data(req["destination"],req["start_date"],req["end_date"])
        plan=generate_plan(req,bundle)
        trip_id=save_trip(req,plan)
        status=f"Trip #{trip_id} saved in local SQLite database."
        if bundle["errors"]: status += "\nSome sources failed: " + " | ".join(bundle["errors"])
        return plan,status,bundle
    except Exception as exc: raise gr.Error(f"Trip generation failed: {exc}")
def chat_reply(message, history, context):
    if not context:
        return "Generate a trip plan first, then paste its plan or collected data into the context box."
    return ("I can explain the supplied trip context, but I cannot verify live fares or booking availability.\\n\\n"
            + context[:3500] + "\\n\\nYour question: " + message
            + "\\n\\nPlease treat any missing information as unavailable in the collected data.")

def vision_action(path):
    if not path: return "Upload an image first.",None
    try:
        import cv2
        result,edges=analyze_image(path)
        f=tempfile.NamedTemporaryFile(delete=False,suffix=".png"); cv2.imwrite(f.name,edges)
        return f"**OpenCV result**\n\n- Size: {result['width']} × {result['height']}\n- Channels: {result['channels']}\n- Edge pixel ratio: {result['edge_pixel_ratio']}\n\n{result['analysis']}",f.name
    except Exception as exc: return f"Image analysis failed: {exc}",None
with gr.Blocks(title="AI Smart Travel Agent India",theme=gr.themes.Soft()) as demo:
    gr.Markdown("# 🇮🇳 AI-Powered Smart Travel Agent – India\nFive-tier architecture: UI → Master Agent → Specialized Agents → Public Data Tools → Final Output.")
    with gr.Tab("Plan a Trip"):
        with gr.Row():
            origin=gr.Textbox(label="Starting city",placeholder="Maihar, Madhya Pradesh")
            destination=gr.Textbox(label="Destination",placeholder="Manali, Himachal Pradesh, India")
        with gr.Row():
            start=gr.Textbox(label="Departure (YYYY-MM-DD)",value=str(date.today()+timedelta(days=7)))
            end=gr.Textbox(label="Return (YYYY-MM-DD)",value=str(date.today()+timedelta(days=10)))
        with gr.Row():
            travellers=gr.Number(label="Travellers",value=2,precision=0)
            budget=gr.Number(label="Total budget (₹)",value=25000,precision=0)
        with gr.Row():
            mode=gr.Dropdown(["Train","Bus","Flight","Mixed","Not decided"],value="Train",label="Preferred transport")
            trip_type=gr.Dropdown(["Solo","Family","Friends","Couple","Business"],value="Solo",label="Trip type")
        interests=gr.Textbox(label="Interests",placeholder="nature, sightseeing, adventure, history")
        go=gr.Button("🚀 Generate Complete Trip Plan",variant="primary")
        plan=gr.Markdown()
        status=gr.Markdown()
        data=gr.JSON(label="Collected data for project demonstration")
        go.click(build_trip,[origin,destination,start,end,travellers,budget,mode,trip_type,interests],[plan,status,data])
    with gr.Tab("AI Travel Chat"):
        gr.Markdown("Ask questions grounded in the trip context. Paste the generated plan or collected data below.")
        chat_context=gr.Textbox(label="Trip context",lines=5,placeholder="Paste the generated trip plan here")
        gr.ChatInterface(fn=chat_reply,additional_inputs=[chat_context])
    with gr.Tab("Computer Vision – OpenCV"):
        gr.Markdown("Upload a landmark image to demonstrate grayscale preprocessing and Canny edge detection. This is image processing, not landmark recognition.")
        img=gr.Image(type="filepath",label="Upload image")
        run=gr.Button("Analyze image")
        vision_text=gr.Markdown()
        edge_img=gr.Image(label="Canny edge output")
        run.click(vision_action,[img],[vision_text,edge_img])
    with gr.Tab("Architecture"):
        gr.Markdown("### Five tiers\n1. User Interface: Gradio form and image upload.\n2. Master AI Agent: validates request and coordinates tasks; Gemini optional with rule-based fallback.\n3. Specialized Agents: destination, attractions, hotels, food, weather and computer vision.\n4. Tools & Data: Nominatim, Overpass/OpenStreetMap, Open-Meteo, Wikipedia, OpenCV and SQLite.\n5. Final Output: collected listings, weather, itinerary and budget guidance.\n\n**Limitations:** no live ticket booking, hotel booking, guaranteed fares, seats, ratings or availability.")
if __name__=="__main__":
    demo.launch(server_name="0.0.0.0", server_port=int(os.environ.get("PORT", "7860")), share=False)
