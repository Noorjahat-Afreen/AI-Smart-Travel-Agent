from config import GEMINI_API_KEY, GEMINI_MODEL
def fallback_plan(req, data):
    lines = [f"# Trip plan: {req.get('origin') or 'Origin not specified'} → {req['destination']}",
    f"- Dates: {req['start_date']} to {req['end_date']}", f"- Travellers: {req['travellers']}",
    f"- Budget entered: ₹{req['budget']:,.0f}", f"- Preferred transport: {req['travel_mode']}",
    f"- Interests: {req.get('interests') or 'General sightseeing'}", "",
    "## Destination overview", data.get("overview",{}).get("summary") or "details unavailable in collected data", "",
    "## Attractions"]
    for p in data.get("attractions",[])[:8]:
        lines.append(f"- **{p['name']}** ({p.get('type','type unavailable')}); {p.get('address','details unavailable in collected data')}. {p.get('map_url','')}")
    if not data.get("attractions"): lines.append("- details unavailable in collected data")
    lines += ["", "## Hotels / accommodation"]
    for p in data.get("hotels",[])[:6]:
        lines.append(f"- **{p['name']}**; address: {p.get('address')}; website: {p.get('website')}")
    if not data.get("hotels"): lines.append("- details unavailable in collected data")
    lines += ["", "## Food discovery"]
    for p in data.get("food",[])[:6]:
        lines.append(f"- **{p['name']}**; cuisine: {p.get('cuisine')}; address: {p.get('address')}")
    if not data.get("food"): lines.append("- details unavailable in collected data")
    lines += ["", "## Weather"]
    for w in data.get("weather",[])[:8]:
        lines.append(f"- {w['date']}: {w['min_c']}–{w['max_c']} °C; max precipitation probability: {w['rain_probability']}%.")
    if not data.get("weather"): lines.append("- Forecast unavailable for these dates.")
    lines += ["", "## Transport and budget", f"- The requested mode is {req['travel_mode']}. Live schedules, fares, seat availability and booking are not provided.",
    "- Divide the entered budget among intercity travel, local transport, accommodation, meals and activities after checking current provider prices.",
    "", "## Data sources and limitations", "- Places: OpenStreetMap. Weather: Open-Meteo. Destination overview: Wikipedia.",
    "- Public listings may be incomplete. No booking, verified prices, ratings or availability are supplied."]
    return "\n".join(lines)
def generate_plan(req, data):
    if not GEMINI_API_KEY: return fallback_plan(req,data)
    try:
        from google import genai
        client = genai.Client(api_key=GEMINI_API_KEY)
        prompt = ("You are the master agent of an educational India travel planner. Create a useful itinerary using ONLY the supplied request and collected JSON. Never invent prices, schedules, ratings, opening hours, availability or features. For missing fields write exactly 'details unavailable in collected data'. Clearly state that bookings are not performed. Include itinerary, attractions, food, hotels, weather, budget guidance, sources and limitations.\nREQUEST="+str(req)+"\nDATA="+str(data))
        response = client.models.generate_content(model=GEMINI_MODEL, contents=prompt)
        return response.text or fallback_plan(req,data)
    except Exception as exc:
        return fallback_plan(req,data) + f"\n\nGemini unavailable; fallback planner used ({str(exc)[:160]})."
