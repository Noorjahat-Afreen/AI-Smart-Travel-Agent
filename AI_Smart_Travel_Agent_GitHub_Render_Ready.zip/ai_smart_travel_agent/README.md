# AI-Powered Smart Travel Agent – India
Lightweight educational implementation of the five-tier architecture shown in your slides.

## Implemented
- Gradio user interface and trip form
- Master agent: optional Gemini reasoning; deterministic fallback works without an API key
- Specialized data collection: Nominatim geocoding, OpenStreetMap/Overpass attractions, hotels and food, Open-Meteo weather, Wikipedia overview
- OpenCV grayscale + Canny edge detection
- SQLite trip history and place cache

## Windows setup (PowerShell)
Python 3.10–3.12 recommended.
```powershell
cd ai_smart_travel_agent
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
copy .env.example .env
python app.py
```
Open the local Gradio URL shown in the terminal (normally http://127.0.0.1:7860).

To enable Gemini, add your key to `.env`:
```env
GEMINI_API_KEY=your_key_here
GEMINI_MODEL=gemini-2.5-flash
```
Without a key, rule-based trip planning still works.

## Important limitations
- Public OpenStreetMap/Nominatim services may throttle requests; use responsibly.
- OpenStreetMap listings can be incomplete or outdated.
- Weather forecasts may not cover far-future dates.
- Transport selection is a preference only: no live timetable, fare, seat availability or booking integration.
- Hotels and restaurants are public map listings, not verified live recommendations.
- OpenCV edge detection does not recognize landmarks. A trained recognition model and licensed dataset would be a separate extension.
- Never claim a booking or price is confirmed by this prototype.

## Project tree
```text
ai_smart_travel_agent/
  app.py
  config.py
  requirements.txt
  .env.example
  README.md
  agents/
    master_agent.py
    specialized_agents.py
  services/
    database.py
    geo.py
    http_client.py
    places.py
    vision.py
    weather.py
    wikipedia.py
  data/  (SQLite database created automatically)
```


## Deploy on Render
1. Upload the extracted project contents (not the ZIP itself) to a GitHub repository.
2. In Render, create a new Web Service and connect that repository.
3. Use build command `pip install -r requirements.txt` and start command `python app.py`.
4. Add `GEMINI_API_KEY` under Render Environment if you want Gemini. Do not commit `.env` or API keys to GitHub.
5. The app binds to `0.0.0.0` and uses Render's `PORT` environment variable.
