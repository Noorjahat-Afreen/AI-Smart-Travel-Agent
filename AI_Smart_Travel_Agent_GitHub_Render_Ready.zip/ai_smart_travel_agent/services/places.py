from services.http_client import get_json
OVERPASS = ["https://overpass-api.de/api/interpreter", "https://overpass.kumi.systems/api/interpreter"]
def find_places(lat, lon, category="tourism", radius=7000, limit=15):
    if category == "tourism":
        selector = 'node(around:{r},{lat},{lon})[tourism~"attraction|museum|viewpoint|gallery|zoo|theme_park"];way(around:{r},{lat},{lon})[tourism~"attraction|museum|viewpoint|gallery|zoo|theme_park"];relation(around:{r},{lat},{lon})[tourism~"attraction|museum|viewpoint|gallery|zoo|theme_park"];'
    elif category == "hotel":
        selector = 'node(around:{r},{lat},{lon})[tourism~"hotel|hostel|guest_house"];way(around:{r},{lat},{lon})[tourism~"hotel|hostel|guest_house"];'
    else:
        selector = 'node(around:{r},{lat},{lon})[amenity~"restaurant|cafe|fast_food"];way(around:{r},{lat},{lon})[amenity~"restaurant|cafe|fast_food"];'
    query = f'[out:json][timeout:25];({selector.format(r=radius, lat=lat, lon=lon)});out center tags;'
    error = None
    data = None
    for url in OVERPASS:
        try:
            data = get_json(url, {"data": query}, timeout=35)
            break
        except Exception as exc:
            error = exc
    if data is None:
        raise RuntimeError(f"OpenStreetMap Overpass request failed: {error}")
    found = {}
    for el in data.get("elements", []):
        tags = el.get("tags", {})
        name = tags.get("name")
        if not name:
            continue
        center = el.get("center", {})
        plat, plon = el.get("lat", center.get("lat")), el.get("lon", center.get("lon"))
        found[name.lower()] = {
            "name": name, "lat": float(plat) if plat is not None else None,
            "lon": float(plon) if plon is not None else None,
            "address": ", ".join(filter(None, [tags.get("addr:housenumber"), tags.get("addr:street"), tags.get("addr:city"), tags.get("addr:state")])) or "Address unavailable in OpenStreetMap data",
            "type": tags.get("tourism") or tags.get("amenity") or category,
            "cuisine": tags.get("cuisine", "Not listed"), "website": tags.get("website", "Not listed"),
            "source": "OpenStreetMap",
            "map_url": f"https://www.openstreetmap.org/?mlat={plat}&mlon={plon}#map=17/{plat}/{plon}" if plat and plon else ""
        }
    return list(found.values())[:limit]
