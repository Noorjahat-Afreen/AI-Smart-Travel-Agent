import os
from dotenv import load_dotenv
load_dotenv()
APP_TITLE = os.getenv("APP_TITLE", "AI-Powered Smart Travel Agent - India")
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "").strip()
GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")
REQUEST_TIMEOUT = int(os.getenv("REQUEST_TIMEOUT", "20"))
USER_AGENT = os.getenv("USER_AGENT", "SmartTravelAgentIndia/1.0 (educational project)")
DB_PATH = os.path.join(os.path.dirname(__file__), "data", "travel_agent.db")
