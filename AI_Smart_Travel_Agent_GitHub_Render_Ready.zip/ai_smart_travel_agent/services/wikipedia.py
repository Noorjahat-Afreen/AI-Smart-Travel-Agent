from services.http_client import get_json
def get_destination_overview(destination):
    data = get_json("https://en.wikipedia.org/w/api.php", {"action":"query","prop":"extracts","exintro":1,"explaintext":1,"redirects":1,"format":"json","titles":destination})
    for page in data.get("query", {}).get("pages", {}).values():
        summary = page.get("extract", "")
        if summary:
            title = page.get("title", destination)
            return {"title": title, "summary": summary[:1800], "url": "https://en.wikipedia.org/wiki/" + title.replace(" ", "_")}
    return {"title": destination, "summary": "Overview unavailable in Wikipedia data.", "url": ""}
