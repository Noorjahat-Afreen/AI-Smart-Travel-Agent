import os, sqlite3, json
from datetime import datetime
from config import DB_PATH
def connection():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn
def init_db():
    with connection() as conn:
        conn.execute('CREATE TABLE IF NOT EXISTS trips (id INTEGER PRIMARY KEY AUTOINCREMENT, created_at TEXT NOT NULL, origin TEXT, destination TEXT, start_date TEXT, end_date TEXT, travellers INTEGER, budget REAL, travel_mode TEXT, request_json TEXT, plan_text TEXT)')
        conn.execute('CREATE TABLE IF NOT EXISTS place_cache (id INTEGER PRIMARY KEY AUTOINCREMENT, cached_at TEXT NOT NULL, destination TEXT, category TEXT, name TEXT, lat REAL, lon REAL, address TEXT, source TEXT, raw_json TEXT)')
        conn.commit()
def save_trip(d, plan):
    with connection() as conn:
        cur = conn.execute('INSERT INTO trips (created_at, origin, destination, start_date, end_date, travellers, budget, travel_mode, request_json, plan_text) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
            (datetime.utcnow().isoformat(), d.get("origin"), d.get("destination"), d.get("start_date"), d.get("end_date"), d.get("travellers"), d.get("budget"), d.get("travel_mode"), json.dumps(d, ensure_ascii=False), plan))
        conn.commit()
        return cur.lastrowid
def cache_places(destination, category, places):
    with connection() as conn:
        for p in places:
            conn.execute('INSERT INTO place_cache (cached_at, destination, category, name, lat, lon, address, source, raw_json) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
                (datetime.utcnow().isoformat(), destination, category, p.get("name"), p.get("lat"), p.get("lon"), p.get("address"), p.get("source"), json.dumps(p, ensure_ascii=False)))
        conn.commit()
