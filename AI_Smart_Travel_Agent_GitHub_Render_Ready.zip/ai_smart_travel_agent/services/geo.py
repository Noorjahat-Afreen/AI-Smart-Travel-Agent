from services.http_client import get_json
def geocode_place(place):
    data = get_json("https://nominatim.openstreetmap.org/search", {"q": place, "format": "jsonv2", "limit": 1})
    if not data:
        return None
    x = data[0]
    return {"lat": float(x["lat"]), "lon": float(x["lon"]), "display_name": x.get("display_name", place)}
