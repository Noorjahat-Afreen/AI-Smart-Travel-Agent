def verify_trip_bundle(request_data, bundle):
    """Checks completeness and labels unsupported live-booking claims."""
    checks = {
        "destination_resolved": bool(bundle.get("location")),
        "attractions_collected": bool(bundle.get("attractions")),
        "hotel_listings_collected": bool(bundle.get("hotels")),
        "food_listings_collected": bool(bundle.get("food")),
        "weather_collected": bool(bundle.get("weather")),
        "booking_status": "not_supported",
        "live_fares": "not_supported"
    }
    warnings = []
    if not checks["attractions_collected"]:
        warnings.append("No attraction listings returned by OpenStreetMap.")
    if not checks["hotel_listings_collected"]:
        warnings.append("No hotel listings returned by OpenStreetMap.")
    if not checks["food_listings_collected"]:
        warnings.append("No food listings returned by OpenStreetMap.")
    if not checks["weather_collected"]:
        warnings.append("Weather forecast unavailable for the requested dates.")
    warnings.append("Live schedules, fares, seats and bookings are not integrated.")
    return {"checks": checks, "warnings": warnings}
