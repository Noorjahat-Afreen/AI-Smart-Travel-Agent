import cv2, numpy as np
def analyze_image(image_path):
    image = cv2.imread(image_path)
    if image is None:
        raise ValueError("Could not read uploaded image.")
    h, w = image.shape[:2]
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    edges = cv2.Canny(gray, 80, 160)
    return {"width":w, "height":h, "channels":image.shape[2] if len(image.shape)==3 else 1,
            "edge_pixel_ratio":round(float(np.count_nonzero(edges))/edges.size, 4),
            "analysis":"OpenCV grayscale preprocessing and Canny edge detection completed. Edge detection does not identify a landmark by itself."}, edges
