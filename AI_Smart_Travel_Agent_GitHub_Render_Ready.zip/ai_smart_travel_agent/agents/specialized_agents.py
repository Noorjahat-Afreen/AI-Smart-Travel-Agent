from concurrent.futures import ThreadPoolExecutor, as_completed
from services.geo import geocode_place
from services.places import find_places
from services.weather import get_weather_forecast
from services.wikipedia import get_destination_overview
from services.database import cache_places
def collect_destination_data(destination, start_date, end_date):
    geo = geocode_place(destination)
    if not geo:
        raise ValueError(f"Could not geocode '{destination}'. Include state and country.")
    lat, lon = geo["lat"], geo["lon"]
    result = {"location":geo, "overview":{}, "attractions":[], "hotels":[], "food":[], "weather":[], "errors":[]}
    jobs = {"overview":lambda:get_destination_overview(destination),
            "attractions":lambda:find_places(lat,lon,"tourism"),
            "hotels":lambda:find_places(lat,lon,"hotel"),
            "food":lambda:find_places(lat,lon,"food"),
            "weather":lambda:get_weather_forecast(lat,lon,start_date,end_date)}
    with ThreadPoolExecutor(max_workers=5) as pool:
        futures = {pool.submit(fn):key for key,fn in jobs.items()}
        for future in as_completed(futures):
            key = futures[future]
            try: result[key] = future.result()
            except Exception as exc: result["errors"].append(f"{key}: {str(exc)[:200]}")
    for category in ["attractions","hotels","food"]:
        try: cache_places(destination,category,result[category])
        except Exception: pass
    from agents.verification_agent import verify_trip_bundle
    result["verification"] = verify_trip_bundle(
        {"destination": destination, "start_date": start_date, "end_date": end_date}, result
    )
    return result
